package com.auth.service.dto;

public class AUthDTO {

}
