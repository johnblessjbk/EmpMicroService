package com.dailylearn.code.dto;

import lombok.Data;

@Data
public class Address {	
	private long id;
	private String city;
	private long pincode;
}
