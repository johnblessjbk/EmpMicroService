package com.dailylearn.code;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DepartmentSeriviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
