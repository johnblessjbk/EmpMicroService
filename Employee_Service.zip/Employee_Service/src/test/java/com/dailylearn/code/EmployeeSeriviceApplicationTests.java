package com.dailylearn.code;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeSeriviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
